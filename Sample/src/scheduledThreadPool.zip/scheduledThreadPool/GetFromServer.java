package scheduledThreadPool;

import java.util.HashMap;
import java.util.Map;

public class GetFromServer {
  Map<Integer,String> map = new HashMap<>();
}
