package scheduledThreadPool;

public interface ISchedulerCallback {
  void onRescheduleThread();
}
